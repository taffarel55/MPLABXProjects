// 8.33s chars
// 10.4167s with another bits
// 20% overhead