// using a multiplexer addressed by a register
// ADMUX
// MUX0, MUX1, MUX2, MUX3
